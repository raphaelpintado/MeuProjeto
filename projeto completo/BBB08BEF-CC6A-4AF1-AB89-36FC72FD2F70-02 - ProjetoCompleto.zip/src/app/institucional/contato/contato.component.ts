import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contato',
  templateUrl: './contato.component.html',
  styles: []
})
export class ContatoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
