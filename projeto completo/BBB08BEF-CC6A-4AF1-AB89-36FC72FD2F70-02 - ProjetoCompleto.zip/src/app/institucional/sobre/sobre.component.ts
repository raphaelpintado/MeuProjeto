import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sobre',
  templateUrl: './sobre.component.html',
  styles: []
})
export class SobreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
