export class Produto {
    id: string;
    nome: string;
    valor: string;
    promocao: boolean;
    valorPromo: string;
    imagem: string;    
}
